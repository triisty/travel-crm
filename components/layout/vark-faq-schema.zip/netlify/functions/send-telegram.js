const https = require('https');

const BOT_TOKEN = '8950778422:AAFtEHfw0MWZNZPNbkXWDGELX2Hj43Qnmu8';
const CHAT_ID   = '917366633';

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { name, email, company, service, message } = JSON.parse(event.body);

    const now = new Date().toLocaleString('ru-RU', {
      timeZone: 'Asia/Baku',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });

    const text = [
      '🚀 *Новая заявка — VARK TECHNOLOGIES*',
      '',
      `👤 *Имя:* ${name}`,
      `📧 *Email:* ${email}`,
      company ? `🏢 *Компания:* ${company}` : null,
      service ? `🛠 *Услуга:* ${service}` : null,
      message ? `💬 *Сообщение:* ${message}` : null,
      '',
      `⏰ ${now}`
    ].filter(l => l !== null).join('\n');

    const payload = JSON.stringify({
      chat_id: CHAT_ID,
      text: text,
      parse_mode: 'Markdown'
    });

    const result = await new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api.telegram.org',
        path: `/bot${BOT_TOKEN}/sendMessage`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: data }));
      });
      req.on('error', reject);
      req.write(payload);
      req.end();
    });

    const parsed = JSON.parse(result.body);
    if (!parsed.ok) {
      return {
        statusCode: 500,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: parsed.description })
      };
    }

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ success: true })
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message })
    };
  }
};
