const https = require('https');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const RESEND_KEY = 're_16TFtDMp_JD1GGehRKGkpfLAhtoXU4YrR';
  const NOTIFY_EMAIL = 'ilkinmame12@gmail.com';

  try {
    const { name, email, company, service, message } = JSON.parse(event.body);

    const htmlBody = `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#0a0f1e;color:#eef2ff;border-radius:16px;overflow:hidden">
        <div style="background:linear-gradient(135deg,#3b82f6,#7c3aed);padding:24px 32px">
          <h2 style="margin:0;font-size:20px;color:#fff">Новая заявка — VARK TECHNOLOGIES</h2>
        </div>
        <div style="padding:32px">
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="padding:8px 0;color:#94a3b8;font-size:13px;width:120px">Имя</td><td style="padding:8px 0;font-weight:600">${name}</td></tr>
            <tr><td style="padding:8px 0;color:#94a3b8;font-size:13px">Email</td><td style="padding:8px 0"><a href="mailto:${email}" style="color:#3b82f6">${email}</a></td></tr>
            ${company ? `<tr><td style="padding:8px 0;color:#94a3b8;font-size:13px">Компания</td><td style="padding:8px 0">${company}</td></tr>` : ''}
            ${service ? `<tr><td style="padding:8px 0;color:#94a3b8;font-size:13px">Услуга</td><td style="padding:8px 0">${service}</td></tr>` : ''}
            ${message ? `<tr><td style="padding:8px 0;color:#94a3b8;font-size:13px;vertical-align:top">Сообщение</td><td style="padding:8px 0">${message}</td></tr>` : ''}
          </table>
          <div style="margin-top:24px;padding:16px;background:rgba(59,130,246,.1);border-radius:8px;font-size:12px;color:#94a3b8">
            VARK TECHNOLOGIES · varktechnologies.netlify.app
          </div>
        </div>
      </div>
    `;

    const payload = JSON.stringify({
      from: 'VARK Website <onboarding@resend.dev>',
      to: [NOTIFY_EMAIL],
      subject: `Новая заявка от ${name}`,
      html: htmlBody
    });

    const result = await new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api.resend.com',
        path: '/emails',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_KEY}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: data }));
      });
      req.on('error', reject);
      req.write(payload);
      req.end();
    });

    if (result.status !== 200 && result.status !== 201) {
      return {
        statusCode: 500,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: result.body })
      };
    }

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ success: true })
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message })
    };
  }
};
